package com.example.savegas.OpcoesMenu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.savegas.R;

public class mediaDeConsumoKmInicialKmFinal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_media_de_consumo_km_inicial_km_final);
    }
}
