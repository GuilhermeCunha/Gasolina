package com.example.savegas.OpcoesMenu;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.savegas.Launcher.Menu;
import com.example.savegas.R;

public class qualCombustivelUsar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_qual_combustivel_usar);


        Button calcular;
        calcular = (Button) findViewById(R.id.calcQualCombUsar);
        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Declarando EditText's
                EditText alcoollitro;
                EditText gaslitro;

                //Declarando String's
                String texto1;
                String texto2;

                //Declarando Double's
                double precoAlcool;
                double precoGasolina;

                //Trazendo os EditText's pras variáveis criadas
                alcoollitro = (EditText) findViewById(R.id.alcoollitro);
                gaslitro = (EditText) findViewById(R.id.gaslitro);

                //Pegando as String's digitadas nos EditText's
                texto1 = alcoollitro.getText().toString();
                texto2 = gaslitro.getText().toString();

                //Transformando essas String's em Double's
                precoAlcool = Double.parseDouble(texto1);
                precoGasolina = Double.parseDouble(texto2);

                //Gerando o resultado a ser exibido
                double result = (precoGasolina*0.7);
                String Mensagem ;

                if(result<precoAlcool){
                    Mensagem = "Gasolina";
                }else{
                    Mensagem = "Alcool";
                }

/*
                        //Criando POP UP do resultado
                        AlertDialog.Builder builder = new AlertDialog.Builder(qualCombustivelUsar.this);
                        builder.setTitle("Dica");
                        builder.setMessage("O combustível mais rentável é: " + Mensagem);
                        builder.create();
                        builder.show();
                        */
                Toast.makeText(getApplicationContext(),"DICA: O combustível mais rentável é: " + Mensagem, Toast.LENGTH_LONG).show();

                Intent i = new Intent(getApplicationContext(), Menu.class);
                Bundle b = new Bundle();
                b.putDouble("PrecoAlcool", precoAlcool);
                b.putDouble("PrecoGasolina", precoGasolina);
                i.putExtras(b);
                startActivity(i);
                finish();

            }
        });


    }
}
